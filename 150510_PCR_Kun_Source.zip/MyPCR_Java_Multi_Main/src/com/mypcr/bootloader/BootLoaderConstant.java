package com.mypcr.bootloader;

public class BootLoaderConstant 
{
	public static final int VENDOR_ID		=	0x04D8;
	public static final int PRODUCT_ID		=	0x003C;
}
