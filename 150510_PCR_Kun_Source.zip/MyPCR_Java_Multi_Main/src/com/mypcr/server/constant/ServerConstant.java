package com.mypcr.server.constant;

public class ServerConstant 
{
	public static final String VERSION_URL		=	"http://mauver.kr/mypcr/Firmware_version.txt";
	public static final String HEX_URL			=	"http://mauver.kr/mypcr/PeltierPCR.hex";
}
