package com.mypcr.beans;

public class State_Oper 
{
	public static final int INIT				=	0x00;
	public static final int COMPLETE			=	0x01;
	public static final int INCOMPLETE			=	0x02;
	public static final int RUN_REFRIGERATOR	=	0x03;
}
