package com.mypcr.config;

public class FirmwareConstant 
{
	public static final int VERSION	=	0x01;
}
