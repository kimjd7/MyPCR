package com.hidapi;

public class DeviceConstant
{
	public static final int VENDOR_ID = 0x04D8;
	public static final int PRODUCT_ID = 0xFB76;
	public static final int MAX_DEVICE	= 20;
	public static final int BUFSIZE = 65;

}
